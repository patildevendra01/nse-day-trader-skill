#!/usr/bin/env python3
"""Order tickets and the decision log for nse-broker (NSE cash equity, rupees). Standard library only.

This tool never talks to a broker and never places anything. It does its
work around the one moment that matters, your yes:

  show      renders each proposed order as a plain-English ticket plus the
            exact parameters (Kite Connect place_order names) for each leg:
            the entry, then a separate stop-loss order and a take-profit
            order, because most Indian brokers have discontinued intraday
            bracket orders. The ticket shows the max loss at the stop. An
            order is READY only if nse-risk passed THIS exact order today
            (matched by fingerprint) and nobody has decided on it yet.
  approve   records your explicit yes for ONE ticket, with your reply word for
            word. It refuses "yes to all", "sure", "ok", a yes that names a
            different stock or amount, and any order that is not READY.
  decline   records a no.
  result    records what happened after the Allow once / Deny card:
            placed (with the broker's order id), denied, or failed.
  fill      records a fill in nse/portfolio.json (cash and shares).
  flatten   builds a sell ticket that closes a symbol's open position by
            flat_by. It still goes through nse-risk and your yes.
  log       prints today's decisions.

    python3 ticket.py show                    # every ticket, READY or not
    python3 ticket.py show --index 1 --json   # one ticket as JSON
    python3 ticket.py approve --index 1 --reply "yes"
    python3 ticket.py result --index 1 --status placed --broker-id 2610300001234
    python3 ticket.py fill --symbol RELIANCE --side buy --qty 34 --price 1432.60
    python3 ticket.py flatten --symbol RELIANCE --qty 34
    python3 ticket.py log

"paper": true (the default) means PAPER mode: nothing is sent to any broker,
because no Indian broker offers a free paper-trading order API. You get the
same tickets and the same yes, and you record a simulated fill with
"result --status placed --filled-qty Q --filled-price P". Set "paper": false
to let Claude send approved tickets through your broker connector.

Everything is written to nse/state/broker.json (append only). Dates are
India (IST) dates; --now "2026-10-30 10:15" pins the clock.
"""

import argparse
import datetime
import hashlib
import json
import math
import os
import re
import sys

ORDER_FIELDS = ("symbol", "exchange", "side", "qty", "product", "order_type", "limit_price",
                "trigger_price", "validity", "stop_loss", "take_profit")
VALIDITY_WORDS = {"DAY": "good for today", "IOC": "immediate or cancel"}
BROKER_NAMES = {"zerodha": "Zerodha Kite", "kite": "Zerodha Kite", "dhan": "Dhan", "upstox": "Upstox",
                "angelone": "Angel One", "angel": "Angel One", "groww": "Groww", "other": "your broker"}
YES_WORDS = ("yes", "y")
BATCH_WORDS = {"all", "every", "everything", "rest", "remaining", "them", "both", "batch", "each"}
DOUBT_WORDS = {"no", "not", "dont", "don't", "wait", "cancel", "stop", "but", "maybe", "later",
               "hold", "unless", "if"}
EPS = 1e-9
STOP_LIMIT_PCT = 0.3     # an "SL" stop-loss's limit sits this percent under its trigger


class TicketError(Exception):
    pass


# ---------------------------------------------------------------- time (India: IST = UTC+05:30, no daylight saving)

IST = datetime.timedelta(hours=5, minutes=30)


def to_ist(utc):
    return utc.replace(tzinfo=None) + IST


def ist_to_utc(local):
    return local.replace(tzinfo=None) - IST


def parse_now(text):
    """ISO time -> naive UTC. A time without an offset is taken as India time (IST)."""
    if not text:
        return datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0, tzinfo=None)
    t = text.strip().replace("Z", "+00:00")
    try:
        dt = datetime.datetime.fromisoformat(t)
    except ValueError:
        raise TicketError("--now wants a time like \"2026-10-30 10:15\" (India time) or ...Z (UTC)")
    if dt.tzinfo is None:
        return ist_to_utc(dt)
    return (dt - dt.utcoffset()).replace(tzinfo=None)


def ist_iso(now_utc):
    """naive UTC -> "2026-10-30T10:15:00+05:30" (India wall clock with its offset)."""
    return "%s+05:30" % to_ist(now_utc).replace(microsecond=0).isoformat()


# ---------------------------------------------------------------- files

def read_json(path, what, required=True):
    if not path or not os.path.exists(path):
        if required:
            raise TicketError("no %s at %s" % (what, path))
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except json.JSONDecodeError as e:
        raise TicketError("%s is not valid JSON: %s" % (path, e))


def write_json(path, data):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
        fh.write("\n")
    os.replace(tmp, path)


def rec_day(rec):
    """The trading day a decision belongs to: its "date" (the day it was made under), else the day of "at"."""
    return str(rec.get("date") or str(rec.get("at", ""))[:10])


def bare(sym):
    s = str(sym or "").strip().upper()
    for suf in (".NS", ".BO"):
        if s.endswith(suf):
            s = s[:-len(suf)]
    return s


# ---------------------------------------------------------------- the order

def fingerprint(order):
    """Same function as nse-risk/check.py: identifies the exact order."""
    core = {k: order[k] for k in ORDER_FIELDS if k in order and order[k] is not None}
    blob = json.dumps(core, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


def _str_num(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        f = float(v)
        return str(int(f)) if f == int(f) else repr(f)
    return str(v)


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _group(n):
    s = str(int(n))
    if len(s) <= 3:
        return s
    head, tail = s[:-3], s[-3:]
    parts = []
    while len(head) > 2:
        parts.insert(0, head[-2:])
        head = head[:-2]
    if head:
        parts.insert(0, head)
    return ",".join(parts + [tail])


def _money(v):
    """1234567.5 -> "₹12,34,567.50" (Indian digit grouping); whole rupees drop the .00."""
    x = float(v)
    neg = x < 0
    x = abs(x)
    whole = int(x)
    frac = int(round((x - whole) * 100))
    if frac == 100:
        whole, frac = whole + 1, 0
    return ("-" if neg else "") + "₹" + _group(whole) + ("" if frac == 0 else ".%02d" % frac)


def _p(v):
    return "%.2f" % float(v)


def _tick_down(x, tick):
    t = int(round(float(tick) * 100))
    return math.floor(float(x) * 100.0 / t + EPS) * t / 100.0


def tick_of(cfg):
    t = _f((cfg or {}).get("tick"))
    return t if t and t > 0 else 0.05


def has_legs(order):
    """An entry that carries its stop_loss / take_profit legs."""
    return order.get("stop_loss") is not None or order.get("take_profit") is not None


def _otype(order):
    return str(order.get("order_type", "market")).strip().lower().replace("_", "-")


def _kite_type(t):
    return {"market": "MARKET", "limit": "LIMIT", "sl": "SL", "sl-m": "SL-M"}.get(t, str(t).upper())


def entry_params(order):
    """The entry leg as Kite Connect place_order parameters (names as in Kite's API; map them to
    whatever your broker's connector calls them). "why" and "plan" are ours and are never sent."""
    t = _otype(order)
    p = {"variety": "regular", "exchange": str(order.get("exchange") or "NSE").upper(),
         "tradingsymbol": bare(order.get("symbol")),
         "transaction_type": str(order.get("side", "")).upper(),
         "order_type": _kite_type(t),
         "quantity": int(round(_f(order.get("qty")) or 0)),
         "product": str(order.get("product") or "MIS").upper(),
         "validity": str(order.get("validity") or "DAY").upper()}
    if t in ("limit", "sl") and order.get("limit_price") is not None:
        p["price"] = float(order["limit_price"])
    if t in ("sl", "sl-m") and order.get("trigger_price") is not None:
        p["trigger_price"] = float(order["trigger_price"])
    return p


def legs(order, cfg=None):
    """[(role, params)]: the entry, then (for an entry with legs) the stop-loss and the take-profit.
    The two exit legs are sells of the same quantity, placed ONLY after the entry has filled."""
    out = [("entry", entry_params(order))]
    if not has_legs(order):
        return out
    base = entry_params(order)
    opposite = "SELL" if base["transaction_type"] == "BUY" else "BUY"
    common = {"variety": "regular", "exchange": base["exchange"], "tradingsymbol": base["tradingsymbol"],
              "transaction_type": opposite, "quantity": base["quantity"], "product": base["product"],
              "validity": "DAY"}
    stop_type = str((cfg or {}).get("stop_type") or "SL-M").upper()
    if order.get("stop_loss") is not None:
        trig = float(order["stop_loss"])
        s = dict(common)
        if stop_type == "SL":
            pct = _f((cfg or {}).get("stop_limit_pct")) or STOP_LIMIT_PCT
            s.update(order_type="SL", trigger_price=trig,
                     price=_tick_down(trig * (1 - pct / 100.0), tick_of(cfg)))
        else:
            s.update(order_type="SL-M", trigger_price=trig)
        out.append(("stop-loss", s))
    if order.get("take_profit") is not None:
        t = dict(common)
        t.update(order_type="LIMIT", price=float(order["take_profit"]))
        out.append(("take-profit", t))
    return out


def tool_input(order):
    """The entry leg's exact parameters (the first thing Claude sends)."""
    return entry_params(order)


def max_loss(order):
    """(rupees, stop) lost if the stop fills exactly at the stop, or (None, stop)."""
    stop = _f(order.get("stop_loss")) or _f((order.get("plan") or {}).get("stop"))
    q = _f(order.get("qty"))
    if not stop or not q:
        return None, stop
    plan = order.get("plan") or {}
    if _otype(order) == "limit" and _f(order.get("limit_price")):
        entry = _f(order["limit_price"])
    elif _f(plan.get("max_loss")) is not None:
        return round(_f(plan["max_loss"]), 2), stop
    else:
        entry = _f(plan.get("entry"))
    if not entry:
        return None, stop
    risk = abs(entry - stop)
    return round(q * int(round(risk * 100)) / 100.0, 2), stop


def plain_parts(order):
    """The ticket in plain words, one part per line."""
    side = str(order.get("side", "")).upper()
    sym = bare(order.get("symbol")) or "?"
    typ = _otype(order)
    tif = VALIDITY_WORDS.get(str(order.get("validity", "DAY")).upper(), order.get("validity"))
    prod = str(order.get("product") or "MIS").upper()
    exch = str(order.get("exchange") or "NSE").upper()
    q = _str_num(order.get("qty"))
    if typ == "limit":
        how = "limit %s" % _p(order.get("limit_price"))
    elif typ == "sl":
        how = "stop-limit, trigger %s, limit %s" % (_p(order.get("trigger_price")), _p(order.get("limit_price")))
    elif typ == "sl-m":
        how = "stop-market, trigger %s" % _p(order.get("trigger_price"))
    else:
        how = "market"
    parts = ["%s %s %s (%s, %s), %s, %s" % (side, q, sym, exch, prod, how, tif)]
    if has_legs(order):
        opp = "SELL" if side == "BUY" else "BUY"
        if order.get("stop_loss") is not None:
            parts.append("then stop-loss: %s %s at trigger %s" % (opp, q, _p(order["stop_loss"])))
        if order.get("take_profit") is not None:
            parts.append("then take-profit: %s %s at limit %s" % (opp, q, _p(order["take_profit"])))
        loss, stop = max_loss(order)
        if loss is not None:
            parts.append("max loss about %s if the stop fills at %s (it can fill worse in a fast market)"
                         % (_money(loss), _p(stop)))
    return parts


def plain(order):
    """BUY 34 RELIANCE (NSE, MIS), market, good for today / then stop-loss: SELL 34 at trigger 1424.30 / ..."""
    return " / ".join(plain_parts(order))


def amount_numbers(order):
    nums = []
    for k in ("qty", "limit_price", "trigger_price", "stop_loss", "take_profit"):
        if order.get(k) is not None:
            v = _f(order[k])
            if v is not None:
                nums.append(v)
    loss, _ = max_loss(order)
    if loss is not None:
        nums.append(loss)
    return nums


def parse_yes(reply, order, batch_symbols=()):
    """Is this reply an explicit yes for THIS one order? Returns (ok, why)."""
    raw = (reply or "").strip()
    if not raw:
        return False, "the reply is empty"
    if "?" in raw:
        return False, "the reply is a question, not a yes"
    words = re.findall(r"[a-z']+", raw.lower())
    if not words or words[0] not in YES_WORDS:
        return False, "only a reply that starts with \"yes\" counts (not ok, sure, go, do it)"
    if BATCH_WORDS & set(words):
        return False, "a yes covers one order at a time, not a batch"
    if DOUBT_WORDS & set(words[1:]):
        return False, "the reply has a condition or a doubt in it; ask again"
    sym = bare(order.get("symbol"))
    tokens = set(re.findall(r"[A-Z][A-Z0-9&.\-]*", raw.upper()))
    others = {bare(s) for s in batch_symbols} - {sym}
    named = tokens & others
    if named:
        return False, "the reply names %s, but this order is for %s" % (", ".join(sorted(named)), sym)
    nums = []
    for n in re.findall(r"\d[\d,]*(?:\.\d+)?", raw):
        try:
            nums.append(float(n.replace(",", "")))
        except ValueError:
            continue
    if nums:
        want = amount_numbers(order)
        if not any(abs(n - w) < 0.005 for n in nums for w in want):
            return False, "the reply says %s, but this order is %s" % (
                ", ".join(_str_num(n) for n in nums), plain(order))
    return True, "explicit yes for %s" % plain(order)


# ---------------------------------------------------------------- state

def load_state(path):
    return read_json(path, "broker state", required=False) or {"orders": []}


def latest(state, fp, today):
    """The latest decision recorded today for this fingerprint, or None."""
    found = None
    for rec in state.get("orders", []):
        if rec.get("fingerprint") == fp and rec_day(rec) == today:
            found = rec
    return found


def risk_verdict(risk, fp, today):
    if not risk:
        return None, "nse-risk has not checked these orders (run check.py)"
    if risk.get("date") != today:
        return None, "the risk check is from %s, not today; run check.py again" % risk.get("date")
    for r in risk.get("results", []):
        if r.get("fingerprint") == fp:
            return r, None
    return None, "this exact order was not in the last risk check (it changed or is new); run check.py again"


def status_of(order, risk, state, today):
    """(ready, label, risk_result)"""
    fp = fingerprint(order)
    rv, why = risk_verdict(risk, fp, today)
    if rv is None:
        return False, "NOT READY: " + why, None
    if rv.get("verdict") != "PASS":
        return False, "BLOCKED by nse-risk: " + "; ".join(rv.get("reasons", [])), rv
    rec = latest(state, fp, today)
    if rec:
        st = rec.get("status")
        if st == "approved":
            return False, "APPROVED by you at %s, waiting for the order to be placed" % rec.get("at"), rv
        return False, "DONE: %s at %s" % (st, rec.get("at")), rv
    return True, "READY: nse-risk PASS, waiting for your yes", rv


def kind_of(order, rv):
    """entry or exit, as nse-risk saw it (older checks: a buy is an entry)."""
    if rv and rv.get("kind"):
        return rv["kind"]
    return "entry" if str(order.get("side", "")).lower() == "buy" else "exit"


# ---------------------------------------------------------------- rendering

def broker_name(cfg):
    b = str(cfg.get("broker", "zerodha")).lower()
    return BROKER_NAMES.get(b, str(cfg.get("broker")).title())


def render(order, idx, total, cfg, risk, state, today):
    ready, label, rv = status_of(order, risk, state, today)
    paper = cfg.get("paper", True)
    mode = "PAPER mode (nothing is sent to a broker)" if paper else "LIVE ACCOUNT, REAL MONEY"
    lines = ["ORDER %d of %d, %s, %s" % (idx, total, mode, broker_name(cfg))]
    for part in plain_parts(order):
        lines.append("  " + part)
    if order.get("why"):
        lines.append("  why: " + order["why"])
    lines.append("  " + label)
    for w in (rv or {}).get("warnings", []):
        lines.append("  note: " + w)
    if paper:
        lines.append("  Paper mode: nothing is placed. After your yes, record a simulated fill with")
        lines.append("  ticket.py result --index %d --status placed --filled-qty Q --filled-price P." % idx)
    else:
        lines.append("  Claude places it with your broker connector's order tool, one leg at a time, using these")
        lines.append("  parameters (Kite Connect names; map them to the connector's own fields, and read the")
        lines.append("  connector's tool list rather than guessing names):")
    for role, params in legs(order, cfg):
        lines.append("  %s:" % role)
        for l in json.dumps(params, indent=2).splitlines():
            lines.append("    " + l)
    if has_legs(order):
        lines.append("  Place the stop-loss and take-profit only AFTER the entry has filled: a sell placed first would")
        lines.append("  open a short MIS position. Most Indian brokers have no intraday bracket order, so these are two")
        lines.append("  separate orders and they do NOT cancel each other: when one fills, cancel the other yourself.")
    if ready:
        lines.append("  Reply \"yes\" to approve this ticket (the entry and its two exit orders), or \"no\" to skip it.")
        if not paper:
            lines.append("  Claude's own card then asks again for each order: Allow once places it, Deny stops it.")
    return "\n".join(lines), ready


def ticket_json(order, idx, cfg, risk, state, today):
    ready, label, rv = status_of(order, risk, state, today)
    loss, stop = max_loss(order)
    return {"index": idx, "ready": ready, "status": label, "plain": plain(order),
            "fingerprint": fingerprint(order), "paper": bool(cfg.get("paper", True)),
            "broker": cfg.get("broker", "zerodha"), "tool": "your broker connector's order-placement tool",
            "tool_input": tool_input(order), "legs": [{"role": r, "params": p} for r, p in legs(order, cfg)],
            "why": order.get("why", ""), "has_legs": has_legs(order), "max_loss": loss, "stop": stop}


# ---------------------------------------------------------------- fills -> portfolio

def apply_fill(portfolio_path, cfg, symbol, side, qty, price, date):
    """Record a filled order in nse/portfolio.json: cash and shares, with a
    cost-basis lot per buy (oldest lots are relieved first on a sell)."""
    pf = read_json(portfolio_path, "portfolio", required=False)
    if pf is None:
        budget = cfg.get("budget")
        if not budget:
            raise TicketError("no %s yet and no budget in the config to start it from" % portfolio_path)
        pf = {"cash": float(budget), "positions": []}
    symbol = bare(symbol)
    qty, price = float(qty), float(price)
    if qty <= 0 or price <= 0:
        raise TicketError("a fill needs a positive qty and price")
    cost = round(qty * price, 2)
    pos = None
    for p in pf.setdefault("positions", []):
        if bare(p.get("ticker") or p.get("symbol")) == symbol:
            pos = p
    if side == "buy":
        if pos is None:
            pos = {"ticker": symbol, "shares": 0.0, "lots": []}
            pf["positions"].append(pos)
        lots = pos.setdefault("lots", [])
        lots.append({"id": "%s-%d" % (symbol, len(lots) + 1), "date": date, "shares": qty, "cost": cost})
        pos["shares"] = round(float(pos.get("shares", 0)) + qty, 6)
        pf["cash"] = round(float(pf.get("cash", 0)) - cost, 2)
    else:
        if pos is None or float(pos.get("shares", 0)) + 1e-9 < qty:
            raise TicketError("cannot record selling %s %s: the portfolio holds %s"
                              % (_str_num(qty), symbol, pos.get("shares", 0) if pos else 0))
        left = qty
        for lot in sorted(pos.get("lots", []), key=lambda l: l.get("date", "")):
            if left <= 1e-9:
                break
            take = min(left, float(lot["shares"]))
            per = float(lot["cost"]) / float(lot["shares"]) if float(lot["shares"]) else 0
            lot["cost"] = round(float(lot["cost"]) - per * take, 2)
            lot["shares"] = round(float(lot["shares"]) - take, 6)
            left -= take
        pos["lots"] = [l for l in pos.get("lots", []) if float(l["shares"]) > 1e-9]
        pos["shares"] = round(float(pos["shares"]) - qty, 6)
        if pos["shares"] <= 1e-9:
            pf["positions"].remove(pos)
        pf["cash"] = round(float(pf.get("cash", 0)) + cost, 2)
    write_json(portfolio_path, pf)
    return pf


def log_fill(state_path, now, today, symbol, side, qty, price):
    """A fill in the log, so the day's trades are on record (a buy and a sell the same day)."""
    state = load_state(state_path)
    state.setdefault("orders", []).append({
        "at": ist_iso(now), "date": today, "status": "filled", "symbol": bare(symbol), "side": side,
        "qty": _str_num(float(qty)), "price": float(price),
        "plain": "%s %s %s at %s" % (side.upper(), _str_num(float(qty)), bare(symbol), _p(price))})
    write_json(state_path, state)


# ---------------------------------------------------------------- commands

def _clock(a):
    now = parse_now(getattr(a, "now", None))
    today = getattr(a, "today", None) or to_ist(now).date().isoformat()
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", today):
        raise TicketError("--today wants a date like 2026-10-30")
    return now, today


def _load(a):
    doc = read_json(a.orders, "orders file (run nse-budget, or ticket.py flatten, first)")
    orders = doc.get("orders", doc) if isinstance(doc, dict) else doc
    if not isinstance(orders, list) or not orders:
        raise TicketError("no orders in %s" % a.orders)
    cfg = read_json(a.config, "config", required=False) or {}
    risk = read_json(a.risk, "risk check", required=False)
    state = load_state(a.state)
    now, today = _clock(a)
    return orders, cfg, risk, state, today, now


def _pick(orders, index):
    if index is None:
        raise TicketError("say which order: --index N")
    if not 1 <= index <= len(orders):
        raise TicketError("there is no order %d (there are %d)" % (index, len(orders)))
    return orders[index - 1]


def cmd_show(a):
    orders, cfg, risk, state, today, now = _load(a)
    picks = [(a.index, _pick(orders, a.index))] if a.index else list(enumerate(orders, 1))
    if a.json:
        out = [ticket_json(o, i, cfg, risk, state, today) for i, o in picks]
        print(json.dumps(out[0] if a.index else out, indent=2))
        return 0 if any(t["ready"] for t in out) else 1
    blocks, any_ready = [], False
    for i, o in picks:
        text, ready = render(o, i, len(orders), cfg, risk, state, today)
        blocks.append(text)
        any_ready = any_ready or ready
    print("\n\n".join(blocks))
    print("\nOne ticket at a time: a yes covers one ticket, never the batch. Education and tooling, "
          "not financial advice.")
    return 0 if any_ready else 1


def cmd_approve(a):
    orders, cfg, risk, state, today, now = _load(a)
    order = _pick(orders, a.index)
    ready, label, rv = status_of(order, risk, state, today)
    if not ready:
        raise TicketError("order %d is not ready: %s" % (a.index, label))
    ok, why = parse_yes(a.reply, order, [o.get("symbol", "") for o in orders])
    if not ok:
        print("Not recorded: %s. Ask the user again with the ticket for order %d." % (why, a.index))
        return 1
    loss, stop = max_loss(order)
    rec = {"at": ist_iso(now), "date": today, "index": a.index, "fingerprint": fingerprint(order),
           "symbol": bare(order.get("symbol")), "side": order.get("side"),
           "qty": order.get("qty"), "kind": kind_of(order, rv), "max_loss": loss, "stop": stop,
           "plain": plain(order), "status": "approved", "reply": a.reply,
           "paper": bool(cfg.get("paper", True)), "broker": cfg.get("broker", "zerodha")}
    state.setdefault("orders", []).append(rec)
    write_json(a.state, state)
    print("Recorded your yes for order %d: %s." % (a.index, plain(order)))
    if cfg.get("paper", True):
        print("Paper mode: do not call any broker tool. Record the simulated fill with: ticket.py result "
              "--index %d --status placed --filled-qty %s --filled-price PRICE" % (a.index, _str_num(order.get("qty"))))
    else:
        print("Now place the entry with your broker connector's order tool, with exactly:")
        print(json.dumps(tool_input(order), indent=2))
        print("Claude's card shows Allow once / Deny. Then: ticket.py result --index %d --status "
              "placed|denied|failed" % a.index)
        if has_legs(order):
            print("After the entry fills, place the stop-loss and take-profit legs shown by ticket.py show "
                  "(each behind its own Allow once).")
    return 0


def cmd_decline(a):
    orders, cfg, risk, state, today, now = _load(a)
    order = _pick(orders, a.index)
    rec = {"at": ist_iso(now), "date": today, "index": a.index, "fingerprint": fingerprint(order),
           "symbol": bare(order.get("symbol")), "side": order.get("side"),
           "plain": plain(order), "status": "declined", "reply": a.reply or "no"}
    state.setdefault("orders", []).append(rec)
    write_json(a.state, state)
    print("Recorded: you said no to order %d (%s). Nothing was sent." % (a.index, plain(order)))
    return 0


def cmd_result(a):
    orders, cfg, risk, state, today, now = _load(a)
    order = _pick(orders, a.index)
    fp = fingerprint(order)
    rec = latest(state, fp, today)
    if not rec or rec.get("status") != "approved":
        raise TicketError("order %d has no yes recorded today; a result can only follow an approval" % a.index)
    new = {"at": ist_iso(now), "date": today, "index": a.index, "fingerprint": fp, "symbol": rec["symbol"],
           "side": rec["side"], "plain": rec["plain"], "status": a.status}
    for k in ("qty", "kind", "max_loss", "stop"):
        if rec.get(k) is not None:
            new[k] = rec[k]
    if cfg.get("paper", True):
        new["paper"] = True
    if a.broker_id:
        new["broker_order_id"] = a.broker_id
    if a.note:
        new["note"] = a.note
    state["orders"].append(new)
    write_json(a.state, state)
    print("Recorded order %d as %s." % (a.index, a.status))
    if a.status == "placed" and a.filled_qty and a.filled_price:
        apply_fill(a.portfolio, cfg, rec["symbol"], rec["side"], a.filled_qty, a.filled_price, today)
        log_fill(a.state, now, today, rec["symbol"], rec["side"], a.filled_qty, a.filled_price)
        print("Added the fill to %s." % a.portfolio)
    elif a.status == "placed":
        print("When it fills, record it: ticket.py fill --symbol %s --side %s --qty Q --price P"
              % (rec["symbol"], rec["side"]))
    if a.status == "placed" and rec.get("kind") == "entry" and has_legs(order):
        print("Now place the stop-loss and the take-profit (they only exist once the entry has filled). When "
              "either fills, record that sell the same way and cancel the other one.")
    return 0


def cmd_fill(a):
    cfg = read_json(a.config, "config", required=False) or {}
    now = parse_now(a.now)
    date = a.date or to_ist(now).date().isoformat()
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
        raise TicketError("--date wants a date like 2026-10-30")
    pf = apply_fill(a.portfolio, cfg, a.symbol, a.side, a.qty, a.price, date)
    log_fill(a.state, now, date, a.symbol, a.side, a.qty, a.price)
    print("Recorded %s %s %s at %s on %s in %s. Cash now %s." % (a.side, a.qty, bare(a.symbol),
                                                                _money(a.price), date, a.portfolio,
                                                                _money(pf["cash"])))
    return 0


def cmd_flatten(a):
    cfg = read_json(a.config, "config", required=False) or {}
    sym = bare(a.symbol)
    now, today = _clock(a)
    source = "the broker's positions"
    if a.qty is not None:
        qty = _f(a.qty)
        if qty is None or qty <= 0 or abs(qty - round(qty)) > 1e-9:
            raise TicketError("--qty wants the whole number of shares you hold, like --qty 34")
    else:
        pf = read_json(a.portfolio, "portfolio", required=False) or {}
        qty = sum(_f(p.get("shares", p.get("qty"))) or 0 for p in pf.get("positions", [])
                  if bare(p.get("ticker") or p.get("symbol")) == sym)
        source = a.portfolio
        if qty <= 1e-9:
            raise TicketError("nothing to flatten: no %s shares in %s. Check your broker's positions "
                              "and pass --qty if you do hold some" % (sym, a.portfolio))
    plan = read_json(a.plan, "plan", required=False) or {}
    flat_by = (plan.get("flat_by") if bare(plan.get("symbol")) == sym else None) \
        or cfg.get("flat_by") or "15:15"
    order = {"symbol": sym, "exchange": "NSE", "side": "sell", "qty": int(round(qty)),
             "product": str(cfg.get("product") or "MIS").upper(), "order_type": "market", "validity": "DAY",
             "why": "flat by %s IST: closes the %s intraday trade before your broker's auto square-off "
             "(qty from %s)" % (flat_by, sym, source)}
    old = read_json(a.orders, "orders", required=False)
    replaced = len(old.get("orders", [])) if isinstance(old, dict) else 0
    doc = {"created_by": "nse-broker", "created_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "status": "proposed",
           "paper": bool(cfg.get("paper", True)),
           "note": "Flatten ticket. Nothing is placed until nse-risk passes it and you say yes in the chat.",
           "source": "ticket.py flatten %s on %s" % (sym, today), "orders": [order]}
    write_json(a.orders, doc)
    print("Flatten %s: %s (flat by %s IST)." % (sym, plain(order), flat_by))
    print("Wrote it to %s%s." % (a.orders, (" (it replaced %d earlier proposal%s)"
                                             % (replaced, "" if replaced == 1 else "s")) if replaced else ""))
    if a.qty is None:
        print("The qty comes from %s. Check it against your broker's positions before you say yes." % source)
    print("Next:")
    print("  1. nse-risk: check.py. A sell that only closes what you hold is never blocked by the daily")
    print("     limits or the entry window.")
    print("  2. ticket.py show, then the user's yes for this one order.")
    print("  3. FIRST cancel the open stop-loss and take-profit orders for these shares (the connector's")
    print("     orders / cancel tools, each behind Needs approval). If they stay open next to this sell, a")
    print("     leg can fill after it and sell the same shares again, which opens an unwanted short MIS")
    print("     position. Then place the sell with the ticket.")
    return 0


def cmd_log(a):
    state = load_state(a.state)
    now, today = _clock(a)
    rows = [r for r in state.get("orders", []) if a.all or rec_day(r) == today]
    if not rows:
        print("No decisions recorded%s." % ("" if a.all else " today"))
        return 1
    for r in rows:
        extra = (" id " + r["broker_order_id"]) if r.get("broker_order_id") else ""
        reply = (' reply "%s"' % r["reply"]) if r.get("reply") and r["status"] in ("approved", "declined") else ""
        loss = (" max loss %s" % _money(r["max_loss"])) if r.get("max_loss") is not None and r["status"] == "placed" else ""
        idx = ("#%s" % r["index"]) if r.get("index") is not None else "  "
        print("%s  %s %-9s %s%s%s%s" % (r.get("at"), idx, r.get("status"), r.get("plain"), reply, loss, extra))
    placed = sum(1 for r in rows if r.get("status") == "placed")
    print("%d placed%s." % (placed, "" if a.all else " today"))
    return 0


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="Order tickets and your yes (nse-broker). Never places orders.")
    sub = ap.add_subparsers(dest="cmd")

    def clock(p):
        p.add_argument("--now", help="pretend it is this India time (IST), e.g. \"2026-10-30 10:15\"")
        p.add_argument("--today", help="YYYY-MM-DD (default: today in India)")

    def common(p):
        p.add_argument("--orders", default="nse/orders.json")
        p.add_argument("--config", default="nse/config.json")
        p.add_argument("--risk", default="nse/state/risk.json")
        p.add_argument("--state", default="nse/state/broker.json")
        clock(p)

    p = sub.add_parser("show", help="render the tickets")
    common(p)
    p.add_argument("--index", type=int)
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("approve", help="record the user's explicit yes for one order")
    common(p)
    p.add_argument("--index", type=int, required=True)
    p.add_argument("--reply", required=True, help="the user's reply, word for word")
    p = sub.add_parser("decline", help="record a no")
    common(p)
    p.add_argument("--index", type=int, required=True)
    p.add_argument("--reply")
    p = sub.add_parser("result", help="record what happened after the Allow once / Deny card (or a paper fill)")
    common(p)
    p.add_argument("--index", type=int, required=True)
    p.add_argument("--status", required=True, choices=["placed", "denied", "failed"])
    p.add_argument("--broker-id")
    p.add_argument("--note")
    p.add_argument("--filled-qty")
    p.add_argument("--filled-price")
    p.add_argument("--portfolio", default="nse/portfolio.json")
    p = sub.add_parser("fill", help="record a fill in nse/portfolio.json")
    p.add_argument("--symbol", required=True)
    p.add_argument("--side", required=True, choices=["buy", "sell"])
    p.add_argument("--qty", required=True)
    p.add_argument("--price", required=True)
    p.add_argument("--date", help="YYYY-MM-DD (default: today in India)")
    p.add_argument("--now")
    p.add_argument("--portfolio", default="nse/portfolio.json")
    p.add_argument("--config", default="nse/config.json")
    p.add_argument("--state", default="nse/state/broker.json")
    p = sub.add_parser("flatten", help="a sell ticket that closes a symbol's position by flat_by")
    p.add_argument("--symbol", required=True)
    p.add_argument("--qty", help="shares you hold, from your broker's positions (default: nse/portfolio.json)")
    p.add_argument("--orders", default="nse/orders.json", help="where the ticket is written")
    p.add_argument("--portfolio", default="nse/portfolio.json")
    p.add_argument("--plan", default="nse/plan.json")
    p.add_argument("--config", default="nse/config.json")
    clock(p)
    p = sub.add_parser("log", help="today's decisions")
    p.add_argument("--state", default="nse/state/broker.json")
    clock(p)
    p.add_argument("--all", action="store_true")
    a = ap.parse_args(argv)
    if not a.cmd:
        ap.print_help()
        return 1
    try:
        return {"show": cmd_show, "approve": cmd_approve, "decline": cmd_decline, "result": cmd_result,
                "fill": cmd_fill, "flatten": cmd_flatten, "log": cmd_log}[a.cmd](a)
    except TicketError as e:
        print("ticket.py: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
